package com.WalkLiveApp;

public class UserServiceException extends Exception {
    public UserServiceException() {
        super();
    }

    public UserServiceException(String message) {
        super(message);
    }
}
